let products = [
  {
    id: 1,
    name: "White Dress",
    size: "L",
    color: "white",
    price: 1200,
    image: "product1.jpg",
    description: "Good looking white dress",
  },
  {
    id: 2,
    name: "Black Dress",
    size: "M",
    color: "Black",
    price: 1500,
    image: "product2.jpg",
    description: "Good looking black dress",
  },

  {
    id: 3,
    name: "Orange Dress",
    size: "S",
    color: "orange",
    price: 900,
    image: "product3.jpg",
    description: "Good looking orange dress",
  },

  {
    id: 4,
    name: "Indian Kurti",
    size: "M",
    color: "White&orange",
    price: 3000,
    image: "product4.jpg",
    description: "Beautifull Kurti",
  },

  {
    id: 5,
    name: "Navy Blue Top",
    size: "S",
    color: "Blue",
    price: 1300,
    image: "product5.jpg",
    description: "Good looking Top",
  },

  {
    id: 6,
    name: "Indian Dress",
    size: "M",
    color: "Henna",
    price: 1500,
    image: "product6.jpg",
    description: "Good looking Traditional Dress",
  },

  {
    id: 7,
    name: "Red Dress",
    size: "L",
    color: "red",
    price: 2900,
    image: "product7.jpg",
    description: "Good looking red dress",
  },
  {
    id: 8,
    name: "Longsky Dress",
    size: "M",
    color: "skyblue",
    price: 1560,
    image: "product8.jpg",
    description: "Good looking skyblue dress",
  },

  {
    id: 9,
    name: "Yellow Dress",
    size: "S",
    color: "Yellow",
    price: 9000,
    image: "product9.jpg",
    description: "Good looking yellow dress",
  },

  {
    id: 10,
    name: "Lightbrown Dress",
    size: "M",
    color: "Lightbrown",
    price: 3000,
    image: "product10.jpg",
    description: "Good looking lightbrown dress",
  },

  {
    id: 11,
    name: "Brown Dress",
    size: "S",
    color: "Brown",
    price: 1230,
    image: "product11.jpg",
    description: "Good looking Brown dress",
  },

  {
    id: 12,
    name: "Blackgolden Dress",
    size: "M",
    color: "Golden",
    price: 4500,
    image: "product12.jpg",
    description: "Good looking Black and Golden Dress",
  },
];

cart = [];

function displayProducts(productsData, who = "productwrapper") {
  let productsString = "";

  productsData.forEach(function (product, index) {
    let { id, name, image, color, description, price, size } = product;

    if (who == "productwrapper") {
      productsString += ` <div class="product">
        <div class="prodimg">
          <img src="productimages/${image}" width="100%" />
        </div>
        <h3>${name}</h3>
        <p>Price : ${price}$</p>
        <p>Size : ${size}</p>
        <p>Color : ${color}</p>
        <p>${description}</p>
        <p>
          <button onclick="addToCart(${id})">Add to Cart</button>
        </p>
      </div>`;
    } else if (who == "cart") {
      productsString += ` <div class="product">
        <div class="prodimg">
          <img src="productimages/${image}" width="100%" />
        </div>
        <h3>${name}</h3>
        <p>Price : ${price}$</p>
        <p>Size : ${size}</p>
        <p>Color : ${color}</p>
        <p>${description}</p>
        <p>
          <button onclick="removeFromCart(${id})">Remove from Cart</button>
        </p>
      </div>`;
    }
  });

  document.getElementById(who).innerHTML = productsString;
}

displayProducts(products);

function searchProduct(searchValue) {
  let searchedProducts = products.filter(function (product, index) {
    let searchString =
      product.name + " " + product.color + " " + product.description;

    return searchString.toUpperCase().indexOf(searchValue.toUpperCase()) != -1;
  });

  displayProducts(searchedProducts);
}

// this is a function to get a product based on id from a particular array
// @param 1 the array u want to get products from
// @param 2 the id u want to search

function getProductByID(productArray, id) {
  return productArray.find(function (product) {
    return product.id == id;
  });
}

function addToCart(id) {
  // getting the product
  let pro = getProductByID(products, id);

  //   putting in cart
  cart.push(pro);
  displayProducts(cart, "cart");
}

function removeFromCart(id) {
  // getting the index based on id
  let index = cart.findIndex(function (product) {
    return product.id == id;
  });

  //   removing from cart based on index
  cart.splice(index, 1);
  displayProducts(cart, "cart");
}





