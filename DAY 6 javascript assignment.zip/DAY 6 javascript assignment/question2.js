let Buses = [
    
];

function display(superarray) {
  let tabledata = "";

  superarray.forEach(function (Bus, index) {
    let currentrow = `<tr>
    <td>${index + 1}</td>
    <td>${Bus.name}</td>
    <td>${Bus.sourse}</td>
    <td>${Bus.destination}</td>
    <td>${Bus.pc}</td>
    <td>
    <button onclick='deleteBus(${index})'>delete</button>
    <button onclick='showModal(${index})'>update</button>
    </td>
    </tr>`;

    tabledata += currentrow;
  });

  document.getElementsByClassName("tdata")[0].innerHTML = tabledata;

}

display(Buses);

function addBus(e) {
  e.preventDefault();
  let Bus = {};
  let name = document.getElementById("name").value;
  let sourse = document.getElementById("sourse").value;
  let destination = document.getElementById("destination").value;
  let pc = document.getElementById("pc").value;
  Bus.name = name;
  Bus.sourse = sourse;
  Bus.destination = destination;
  Bus.pc = Number(pc);

  Buses.push(Bus);

  display(Buses);

  document.getElementById("name").value = "";
  document.getElementById("sourse").value = "";
  document.getElementById("destination").value = "";
  document.getElementById("pc").value = "";
}

function searchBySourse() {
  let searchValue = document.getElementById("searchSourse").value;

  let newdata = Buses.filter(function (Bus) {
    return (
      Bus.sourse.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
    );
  });

  

  display(newdata);
}

// function searchByDestination() {
//   let searchValue = document.getElementById("searchDestination").value;

//   let newdata = Buses.filter(function (Bus) {
//     return (
//       Bus.destination.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
//     );
//   });

//   display(newdata);
// }



function deleteBus(index) {
  Buses.splice(index, 1);
  display(Buses);
}

let updateIndex;

function copyBus(index) {
  updateIndex = index;
  let Bus = Buses[index];

  document.getElementById("upname").value = Bus.name;
  document.getElementById("upsourse").value = Bus.sourse;
  document.getElementById("updestination").value = Bus.destination;
  document.getElementById("uppc").value = Bus.pc;
}

function updateBus(e) {
  e.preventDefault();
  let Bus = Buses[updateIndex];
  console.log(Bus);
  let name = document.getElementById("upname").value;
  let sourse = document.getElementById("upsourse").value;
  let destination = document.getElementById("updestination").value;
  let pc = document.getElementById("uppc").value;
  Bus.name = name;
  Bus.sourse = sourse;
  Bus.destination = destination;
  Bus.pc = Number(pc);
  console.log(Bus);

  display(Buses);

  // code for hiding from anywhere
  let modal = document.getElementsByClassName("modal")[0];
  modal.style.display = "none";
}

function showModal(index) {
  let modal = document.getElementsByClassName("modal")[0];
  modal.style.display = "block";

  copyBus(index);
}

function hideModal(event) {
  if (event.target.className == "modal") {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "none";
  }
}