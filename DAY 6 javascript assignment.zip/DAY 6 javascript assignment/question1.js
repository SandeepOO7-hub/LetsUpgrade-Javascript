let Employees = [
    
  ];

  function display(superarray) {
    let tabledata = "";
  
    superarray.forEach(function (Employee, index) {
      let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${Employee.name}</td>
      <td>${Employee.age}</td>
      <td>${Employee.city}</td>
      <td>${Employee.salary}</td>
      <td>
      <button onclick='deleteEmployee(${index})'>delete</button>
      <button onclick='showModal(${index})'>update</button>
      </td>
      </tr>`;
  
      tabledata += currentrow;
    });
  
    document.getElementsByClassName("tdata")[0].innerHTML = tabledata;

  }
  
  display(Employees);
  
  function addEmployee(e) {
    e.preventDefault();
    let Employee = {};
    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let city = document.getElementById("city").value;
    let salary = document.getElementById("salary").value;
    Employee.name = name;
    Employee.age = Number(age);
    Employee.city = city;
    Employee.salary = salary;
  
    Employees.push(Employee);
  
    display(Employees);
  
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("city").value = "";
    document.getElementById("salary").value = "";
  }
  
  function searchByName() {
    let searchValue = document.getElementById("searchName").value;
  
    let newdata = Employees.filter(function (Employee) {
      return (
        Employee.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }

  function searchByCity() {
    let searchValue = document.getElementById("searchCity").value;
  
    let newdata = Employees.filter(function (Employee) {
      return (
        Employee.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }


  
  function deleteEmployee(index) {
    Employees.splice(index, 1);
    display(Employees);
  }
  
  let updateIndex;
  
  function copyEmployee(index) {
    updateIndex = index;
    let Employee = Employees[index];
  
    document.getElementById("upname").value = Employee.name;
    document.getElementById("upage").value = Employee.age;
    document.getElementById("upcity").value = Employee.city;
    document.getElementById("upsalary").value = Employee.salary;
  }
  
  function updateEmployee(e) {
    e.preventDefault();
    let Employee = Employees[updateIndex];
    console.log(Employee);
    let name = document.getElementById("upname").value;
    let age = document.getElementById("upage").value;
    let city = document.getElementById("upcity").value;
    let salary = document.getElementById("upsalary").value;
    Employee.name = name;
    Employee.age = Number(age);
    Employee.city = city;
    Employee.salary = salary;
    console.log(Employee);
  
    display(Employees);
  
    // code for hiding from anywhere
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "none";
  }
  
  function showModal(index) {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "block";
  
    copyEmployee(index);
  }
  
  function hideModal(event) {
    if (event.target.className == "modal") {
      let modal = document.getElementsByClassName("modal")[0];
      modal.style.display = "none";
    }
  }