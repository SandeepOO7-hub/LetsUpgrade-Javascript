var staff=[ 
     {name:"Ram",age:38,gender:"male",country: "India",hobbies: "painting",},
     {name:"Shyam",age:24,gender:"male",country: "America",hobbies: "sleeping",}, 
     {name:"Hari",age:35,gender:"male",country: "India",hobbies: "reading books",}, 
     {name:"Sita",age:25,gender:"female",country: "Uganda",hobbies: "cooking",},
     ];

// A     
var resultArray = [];
for(var i=0; i<staff.length; i++) {
  if(staff[i].age < 30) {
    resultArray.push(staff[i]);
  }
}

console.log(resultArray);

// B
var resultArray = [];
for(var i=0; i<staff.length; i++) {
  if(staff[i].country == "India") {
    resultArray.push(staff[i]);
  }
}

console.log(resultArray);