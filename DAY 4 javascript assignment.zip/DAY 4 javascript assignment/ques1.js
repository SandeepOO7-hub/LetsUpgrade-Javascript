function changeImage0() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://i.pinimg.com/originals/c7/6d/a9/c76da9f37d9fccd5a8ef4ec48b5ba2de.jpg";
      
  
    ele.src = newUrl;
  }
  
  function changeImage1() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://s3.r29static.com/bin/entry/ce2/x,80/2169674/image.jpg";
      
  
    ele.src = newUrl;
  }
  
  function changeImage2() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://m.hindustantimes.com/rf/image_size_960x540/HT/p2/2020/06/24/Pictures/_dabbc3d4-b5de-11ea-b3b3-7b919605787e.jpg";
     

    ele.src = newUrl;
  }
  