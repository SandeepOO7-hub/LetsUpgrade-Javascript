let people = [
  {
    name: "Ram",
    age: 24,
    country: "India",
    hobbies: "painting",
   },
   {
     name: "Shyam",
     age: 38,
     country: "India",
     hobbies: "sleeping",
   },
   {
     name: "Hari",
     age: 43,
     country: "India",
     hobbies: "reading books",
   },
   {
    name: "Sita",
    age: 34,
    country: "India",
    hobbies: "cooking",
  },
 ];

 people.forEach(function (people) {
    console.log(people.name);
    console.log(people.age);
    console.log(people.country);
    console.log(people.hobbies);
   });

